package com.example.myapplication;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
public class TenantAdapter extends RecyclerView.Adapter<TenantAdapter.ViewHolder> {
    private List<com.example.myapplication.Tenant> tenantList;

    public TenantAdapter(List<com.example.myapplication.Tenant> tenantList) {
        this.tenantList = tenantList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_tenant, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        com.example.myapplication.Tenant tenant = tenantList.get(position);
        holder.textViewName.setText("Name: " + tenant.getName());
        holder.textViewAge.setText("Age: " + tenant.getAge());
        holder.textViewAddress.setText("Address: " + tenant.getAddress());
        holder.textViewSex.setText("Sex: " + tenant.getSex());
    }

    @Override
    public int getItemCount() {
        return tenantList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewName, textViewAge, textViewAddress, textViewSex;

        public ViewHolder(View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.textViewName);
            textViewAge = itemView.findViewById(R.id.textViewAge);
            textViewAddress = itemView.findViewById(R.id.textViewAddress);
            textViewSex = itemView.findViewById(R.id.textViewSex);
        }
    }
}

