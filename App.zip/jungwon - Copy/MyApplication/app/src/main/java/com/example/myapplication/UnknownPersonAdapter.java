package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.myapplication.R;

import java.util.List;

public class UnknownPersonAdapter extends RecyclerView.Adapter<UnknownPersonAdapter.ViewHolder> {

    private Context context;
    private List<UnknownPerson> unknownPersonList;

    public UnknownPersonAdapter(Context context, List<UnknownPerson> unknownPersonList) {
        this.context = context;
        this.unknownPersonList = unknownPersonList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_unknown_person, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        UnknownPerson person = unknownPersonList.get(position);
        holder.timestamp.setText(person.getTimestamp());

        // Load image using Glide
        Glide.with(context).load(person.getImageUrl()).into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return unknownPersonList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView timestamp;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            timestamp = itemView.findViewById(R.id.timestamp);
        }
    }
}
