package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class OwnerLogin extends AppCompatActivity {
    String password;
    FirebaseFirestore db = FirebaseFirestore.getInstance();


    TextView welcome;
    EditText pass;
    Button go;
    String converted_pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_owner_login);
        getCode();
        welcome = findViewById(R.id.welcome);
        pass = findViewById(R.id.pass);
        go = findViewById(R.id.go);
        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                converted_pass = pass.getText().toString();
                if (converted_pass.equals(password)){
                    Intent intent = new Intent();
                    intent.setClass(v.getContext(), MainActivity.class);
                    startActivity(intent);
                    finish();
                }

            }
        });
    }
    private void getCode(){
        DocumentReference docRef = db.collection("users").document("passcode");
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        password = document.getString("login"); // Get the "login" field
                        Log.d("Firestore", "Login: " + password);
                    } else {
                        Log.d("Firestore", "No such document");
                    }
                } else {
                    Log.w("Firestore", "Error getting document.", task.getException());
                }
            }
        });
    }
}