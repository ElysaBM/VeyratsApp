package com.example.myapplication;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.fragment.app.FragmentTransaction; //added

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class register extends Fragment {
    private static final String TAG = "Firestore";
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    EditText name, age, address, sex;
    Button signup;

    public register() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_register, container, false);

        name = view.findViewById(R.id.name);
        age = view.findViewById(R.id.age);
        address = view.findViewById(R.id.address);
        sex = view.findViewById(R.id.sex);
        signup = view.findViewById(R.id.signup);

        signup.setOnClickListener(v -> registerTenant()); //added
        return view; //added
    }
        //signup.setOnClickListener(new View.OnClickListener() {
            private void registerTenant() {
                String userName = name.getText().toString().trim();
                String userAge = age.getText().toString().trim();
                String userAddress = address.getText().toString().trim();
                String userSex = sex.getText().toString().trim();

                // Check if fields are empty
                if (userName.isEmpty() || userAge.isEmpty() || userAddress.isEmpty() || userSex.isEmpty()) {
                    Toast.makeText(getContext(), "Please fill all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Create Firestore data object
                Map<String, Object> tenantData = new HashMap<>();
                tenantData.put("name", userName);
                tenantData.put("age", userAge);
                tenantData.put("address", userAddress);
                tenantData.put("sex", userSex);

                // Set document name as "tenant_<name>"
                String documentId = "tenant_" + userName.replace(" ", "_"); // Replace spaces with underscores

                // Add to Firestore with a custom document ID
                db.collection("tenants").document(documentId)
                        .set(tenantData)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Log.d(TAG, "Document successfully written as: " + documentId);
                                Toast.makeText(getContext(), "Tenant Registered Successfully!", Toast.LENGTH_SHORT).show();
                                navigateToTenantProfile(documentId); //added
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.w(TAG, "Error adding document: " + e.getMessage(), e);
                                Toast.makeText(getContext(), "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        });
            }
    private void navigateToTenantProfile(String tenantId) { //added
        // Create a new instance of TenantProfile fragment
        TenantProfile tenantProfileFragment = new TenantProfile();

        // Create a bundle to pass the tenant ID
        Bundle bundle = new Bundle();
        bundle.putString("tenantId", tenantId);
        tenantProfileFragment.setArguments(bundle);

        // Replace current fragment with TenantProfile
        FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, tenantProfileFragment);
        transaction.addToBackStack(null); // Allows going back to Register
        transaction.commit();
    }
}


