package com.example.myapplication;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.example.myapplication.R;

import java.util.ArrayList;
import java.util.List;

public class UnknownFragment extends Fragment {

    private RecyclerView recyclerView;
    private UnknownPersonAdapter unknownPersonAdapter;
    private List<UnknownPerson> unknownPersonList;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_unknown, container, false);

        recyclerView = view.findViewById(R.id.recyclerViewUnknownPersons);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Sample data
        unknownPersonList = new ArrayList<>();
        unknownPersonList.add(new UnknownPerson("https://example.com/image1.jpg", "2025-03-24 10:00 AM"));
        unknownPersonList.add(new UnknownPerson("https://example.com/image2.jpg", "2025-03-24 10:30 AM"));

        unknownPersonAdapter = new UnknownPersonAdapter(getContext(), unknownPersonList);
        recyclerView.setAdapter(unknownPersonAdapter);

        return view;
    }
}
