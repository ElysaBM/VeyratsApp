package com.example.myapplication;
public class UnknownPerson {
    private String imageUrl;
    private String timestamp; // This will store the time when the unknown person was detected

    // Default constructor required for Firebase (if used)
    public UnknownPerson() {
    }

    // Constructor to initialize values
    public UnknownPerson(String imageUrl, String timestamp) {
        this.imageUrl = imageUrl;
        this.timestamp = timestamp;
    }

    // Getter for imageUrl
    public String getImageUrl() {
        return imageUrl;
    }

    // Getter for timestamp
    public String getTimestamp() {
        return timestamp;
    }

    // Setter for timestamp (if needed)
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
}
