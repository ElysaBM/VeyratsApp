package com.example.myapplication;
public class Tenant {
    private String name;
    private String age;
    private String address;
    private String sex;

    // Empty constructor required for Firestore
    public Tenant() {}

    public Tenant(String name, String age, String address, String sex) {
        this.name = name;
        this.age = age;
        this.address = address;
        this.sex = sex;
}
    // Getters for RecyclerView Adapter
    public String getName() {
        return name;
    }

    public String getAge() {
        return age;
    }

    public String getAddress() {
        return address;
    }

    public String getSex() {
        return sex;
    }
}
